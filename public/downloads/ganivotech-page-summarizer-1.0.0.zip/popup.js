const SITE = "https://ganivotech.com";
const $ = (id) => document.getElementById(id);
const utm = (path) => `${SITE}${path}?utm_source=chrome-extension&utm_medium=extension&utm_campaign=summarizer`;
$("link-site").href = utm("/");
$("link-more").href = utm("/extensions");

const WPM = 230; // average adult reading speed
const MAX_PARTS = 12;

const prefs = (() => { try { return JSON.parse(localStorage.getItem("prefs") || "{}"); } catch { return {}; } })();
const st = { type: prefs.type || "tldr", length: prefs.length || "short", source: "page", page: null, lang: "en", avail: null, ctrl: null, busy: false, summary: "" };

function toast(msg) {
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 1700);
}

function status(kind, text, items) {
  const el = $("status");
  el.className = "status" + (kind ? " " + kind : "");
  el.replaceChildren(document.createTextNode(text));
  if (items) {
    const ul = document.createElement("ul");
    items.forEach((i) => { const li = document.createElement("li"); li.textContent = i; ul.append(li); });
    el.append(ul);
  }
}

function setBar(fraction) {
  $("bar").hidden = fraction == null;
  if (fraction != null) $("bar-fill").style.width = `${Math.round(Math.min(1, fraction) * 100)}%`;
}

const words = (s) => (s.match(/\S+/g) || []).length;
const mins = (w) => Math.max(1, Math.round(w / WPM));
const readTime = (w) => (w < WPM ? `${Math.max(5, Math.round((w / WPM) * 60))} sec read` : `${mins(w)} min read`);

// ---------- chips ----------
function pick(group, key, value) {
  $(group).querySelectorAll(".chip").forEach((c) => c.classList.toggle("on", c.dataset.v === value));
  st[key] = value;
  localStorage.setItem("prefs", JSON.stringify({ type: st.type, length: st.length }));
}
$("source").addEventListener("click", (e) => { const b = e.target.closest(".chip:not(:disabled)"); if (b) { pick("source", "source", b.dataset.v); refresh(); } });
$("mode").addEventListener("click", (e) => { const b = e.target.closest(".chip"); if (b && !st.busy) { pick("mode", "type", b.dataset.v); refresh(); } });
$("len").addEventListener("click", (e) => { const b = e.target.closest(".chip"); if (b && !st.busy) { pick("len", "length", b.dataset.v); refresh(); } });
pick("mode", "type", st.type);
pick("len", "length", st.length);

// ---------- availability ----------
const baseOpts = () => ({
  type: st.type,
  format: "plain-text",
  length: st.length,
  outputLanguage: "en",
  expectedInputLanguages: [st.lang],
  expectedContextLanguages: ["en"],
});

const REQUIREMENTS = [
  "Google Chrome 138 or newer on Windows, macOS or Linux (not phones or tablets)",
  "About 22 GB of free disk space for Chrome's AI model",
  "A graphics card with more than 4 GB of memory, or 16 GB of RAM and 4 or more CPU cores",
];

async function refresh(quiet) {
  const say = quiet ? () => {} : status;
  const text = st.source === "selection" ? st.page?.selection : st.page?.text;
  if (!st.page) return;
  if (!text || words(text) < 40) {
    st.avail = null;
    $("go").disabled = true;
    say("warn", "There is not enough text here to summarize. Open an article or select a few paragraphs.");
    return;
  }
  if (!("Summarizer" in self)) {
    st.avail = "none";
    $("go").disabled = true;
    say("warn", "This browser does not have Chrome's built-in Summarizer. It needs:", REQUIREMENTS);
    return;
  }
  let a = "unavailable";
  try { a = await Summarizer.availability(baseOpts()); } catch {}
  st.avail = a;
  $("go").disabled = st.busy || a === "unavailable";
  if (a === "unavailable") {
    if (st.lang !== "en") say("warn", `This page looks like it is in "${st.lang}". Chrome's on-device AI can currently summarize English pages on this computer.`);
    else say("warn", "Chrome's on-device AI is not available on this computer. It needs:", REQUIREMENTS);
  } else if (a === "downloadable") {
    say("", "One-time setup: Chrome will download its on-device AI model, a large file that can take several minutes. It needs about 22 GB of free disk space and an unmetered connection.");
    $("go").textContent = "Download AI model and summarize";
  } else if (a === "downloading") {
    say("", "Chrome is still downloading the AI model. You can start now and it will continue.");
    $("go").textContent = "Continue and summarize";
  } else {
    say("ok", "Ready. Everything runs on your device.");
    $("go").textContent = "Summarize";
  }
  if (a === "unavailable") $("go").textContent = "Summarize";
}

// ---------- summarize ----------
async function make(type, length, showProgress) {
  const o = {
    ...baseOpts(),
    type,
    length,
    sharedContext: `Web page titled "${st.page.title}".`,
    signal: st.ctrl.signal,
  };
  if (showProgress) o.monitor = (m) => m.addEventListener("downloadprogress", (e) => { setBar(e.loaded); status("", `Downloading the AI model: ${Math.floor(e.loaded * 100)}%`); });
  const s = await Summarizer.create(o);
  setBar(null);
  return s;
}

// split text on line boundaries into pieces that fit the model's input quota
async function splitToFit(s, text) {
  const usage = await s.measureInputUsage(text);
  if (usage <= s.inputQuota) return [text];
  const maxChars = Math.max(500, Math.floor(s.inputQuota * (text.length / usage) * 0.7));
  const parts = [];
  let cur = "";
  for (const line of text.split("\n")) {
    if (cur && cur.length + line.length + 1 > maxChars) { parts.push(cur); cur = ""; }
    if (line.length > maxChars) {
      for (let i = 0; i < line.length; i += maxChars) parts.push(line.slice(i, i + maxChars));
    } else cur += (cur ? "\n" : "") + line;
  }
  if (cur) parts.push(cur);
  return parts;
}

async function trimToQuota(s, text) {
  let t = text;
  while (t.length > 200 && (await s.measureInputUsage(t)) > s.inputQuota) t = t.slice(0, Math.floor(t.length * 0.8));
  return t;
}

function setBusy(b) {
  st.busy = b;
  $("go").hidden = b;
  $("stop").hidden = !b;
  $("source").querySelectorAll(".chip").forEach((c) => { if (c.dataset.v === "page" || st.page?.selectionWords >= 20) c.disabled = b; });
}

async function run() {
  const text = st.source === "selection" ? st.page.selection : st.page.text;
  const ctx = `Web page titled "${st.page.title}".`;
  st.ctrl = new AbortController();
  setBusy(true);
  $("result").hidden = true;
  st.summary = "";
  let final = null;
  let mid = null;
  try {
    status("", "Starting the on-device AI...");
    final = await make(st.type, st.length, true);

    let input = text;
    const parts = await splitToFit(final, text);
    if (parts.length > 1) {
      mid = await make("tldr", "medium", false);
      const use = parts.slice(0, MAX_PARTS);
      const sums = [];
      for (let i = 0; i < use.length; i++) {
        status("", `This page is long. Reading part ${i + 1} of ${use.length}...`);
        setBar((i + 1) / use.length);
        sums.push(await mid.summarize(use[i], { context: ctx, signal: st.ctrl.signal }));
      }
      setBar(null);
      input = await trimToQuota(final, sums.join("\n\n"));
    }

    status("", "Summarizing...");
    $("result").hidden = false;
    $("out").textContent = "";
    let acc = "";
    for await (const chunk of final.summarizeStreaming(input, { context: ctx, signal: st.ctrl.signal })) {
      // chunks are new text; also tolerate a build that sends the whole summary so far
      acc = acc && chunk.length >= acc.length && chunk.startsWith(acc) ? chunk : acc + chunk;
      $("out").textContent = acc;
    }
    st.summary = acc.trim();
    $("out").textContent = st.summary;
    if (!st.summary) throw new Error("empty");
    const w = words(text);
    const sw = words(st.summary);
    $("saved").textContent = `${w.toLocaleString("en-IN")} words (${readTime(w)}) shortened to ${sw} words (${readTime(sw)}).`;
    status("ok", parts.length > 1 && parts.length > MAX_PARTS ? "Done. This page was very long, so the summary covers the first part." : "Done.");
  } catch (e) {
    $("result").hidden = !st.summary;
    if (e.name === "AbortError") status("warn", "Stopped.");
    else if (e.name === "QuotaExceededError") status("bad", "This text is too long for the on-device AI. Select a shorter part and try again.");
    else if (e.name === "NotAllowedError") status("bad", "Chrome needs you to click the button to start the model download. Please try again.");
    else if (e.name === "NotSupportedError") status("warn", "Chrome's on-device AI cannot summarize this language or setting on this computer.");
    else status("bad", "Could not create a summary. Please try again.");
  } finally {
    setBar(null);
    try { final?.destroy(); mid?.destroy(); } catch {}
    setBusy(false);
    refresh(true);
  }
}

$("go").addEventListener("click", run);
$("stop").addEventListener("click", () => st.ctrl?.abort());

// ---------- share / copy ----------
$("copy").addEventListener("click", () => {
  if (!st.summary) return;
  navigator.clipboard.writeText(`${st.page.title}\n${st.page.url}\n\n${st.summary}`).then(() => toast("Summary copied"));
});
$("wa").addEventListener("click", () => {
  if (!st.summary) return;
  const body = st.summary.replace(/^\s*[-*]\s+/gm, "• ").slice(0, 1500);
  const msg = `*${st.page.title}*\n\n${body}\n\n${st.page.url}`;
  const a = document.createElement("a");
  a.href = `https://wa.me/?text=${encodeURIComponent(msg)}`;
  a.target = "_blank";
  a.rel = "noopener";
  a.click();
});

// ---------- start: read the current tab ----------
(async function init() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: extractPage });
    st.page = result;
  } catch {
    $("page-title").textContent = "This page cannot be read";
    status("warn", "Chrome does not let extensions read this kind of page (for example chrome:// pages, the Web Store or some PDF views). Open a normal web page.");
    return;
  }
  const p = st.page;
  st.lang = (p.lang || "en").toLowerCase().split(/[-_]/)[0] || "en";
  $("page-title").textContent = p.title || p.url;
  $("page-meta").textContent = `${p.words.toLocaleString("en-IN")} words, about ${mins(p.words)} min read`;
  if (p.selectionWords >= 20) {
    const chip = $("source").querySelector('[data-v="selection"]');
    chip.disabled = false;
    chip.textContent = `Selected text (${p.selectionWords} words)`;
    pick("source", "source", "selection");
  }
  refresh();
})();
