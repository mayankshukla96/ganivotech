/*
 * WhatsApp Group Number Extractor — popup
 *
 * The popup is only a remote control and viewer. The scan itself runs in the
 * content script inside the WhatsApp Web tab, so it keeps going (and keeps its
 * results) even if this popup is closed. Reopening the popup re-reads state.
 */
'use strict';

const WHATSAPP_ORIGIN = 'https://web.whatsapp.com/';
const COUNTRY_CODE_KEY = 'wgne.defaultCountryCode';

const UI_TEXT = Object.freeze({
  NOT_WHATSAPP: 'Please open WhatsApp Web first.',
  NO_CONNECTION: 'Could not connect to WhatsApp Web.\nPlease refresh the WhatsApp Web tab and try again.',
  NOTHING_TO_EXPORT: 'There are no numbers to export yet.'
});

const view = {
  tabId: null,
  state: null,
  sortKey: 'index',
  sortDir: 1,
  filter: ''
};

const $ = (id) => document.getElementById(id);

/* ---------------- Chrome helpers ---------------- */

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

function isWhatsAppUrl(url) {
  return typeof url === 'string' && url.startsWith(WHATSAPP_ORIGIN);
}

async function sendToTab(message) {
  if (view.tabId == null) throw new Error('No WhatsApp tab');
  const response = await chrome.tabs.sendMessage(view.tabId, message);
  if (!response) throw new Error('Empty response from content script');
  return response;
}

/**
 * The content script is declared in the manifest, but tabs that were open
 * before the extension was installed/reloaded don't have it yet — inject it.
 */
async function ensureContentScript() {
  try {
    await sendToTab({ action: 'ping' });
  } catch (_) {
    await chrome.scripting.executeScript({ target: { tabId: view.tabId }, files: ['content.js'] });
    await sendToTab({ action: 'ping' });
  }
}

/* ---------------- CSV ---------------- */

/**
 * Escape one CSV field (RFC 4180). Text fields that start with = + - @ are
 * prefixed with ' so spreadsheet apps don't execute them as formulas.
 */
function csvEscape(value, { guardFormula = true } = {}) {
  let s = value == null ? '' : String(value);
  if (guardFormula && /^[=+\-@\t\r]/.test(s)) s = "'" + s;
  if (/[",\r\n]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
  return s;
}

function buildCsv(records) {
  const lines = ['Name,Phone Number'];
  for (const r of records) {
    // Phone numbers are validated as +digits, so they are safe to leave as-is.
    lines.push(csvEscape(r.name || 'Unknown') + ',' + csvEscape(r.phone, { guardFormula: false }));
  }
  return '﻿' + lines.join('\r\n') + '\r\n'; // BOM → Excel reads UTF-8 names correctly
}

function localDateStamp(date = new Date()) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function sanitizeFilenamePart(name) {
  return String(name || '')
    .normalize('NFKC')
    .replace(/[\\/:*?"<>|\u0000-\u001F\u007F]/g, '')   // illegal on Windows/macOS/Linux
    .replace(/[\s.]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 60);
}

function buildFilename(groupName, date = new Date()) {
  const safe = sanitizeFilenamePart(groupName);
  return safe ? `${safe}-numbers-${localDateStamp(date)}.csv` : `whatsapp-group-numbers-${localDateStamp(date)}.csv`;
}

function downloadCsv(csv, filename) {
  // A data: URL (not a blob: URL) keeps working even if the popup closes
  // while Chrome shows a "Save as" dialog. No "downloads" permission needed.
  const link = document.createElement('a');
  link.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
  link.download = filename;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  link.remove();
}

/* ---------------- Rendering ---------------- */

function emptyState() {
  return {
    status: 'READY',
    message: 'Ready',
    groupName: '',
    expectedTotal: null,
    participantsScanned: 0,
    numbersFound: 0,
    notExposedCount: 0,
    notExposedNames: [],
    results: []
  };
}

function render(state) {
  view.state = state || emptyState();
  const s = view.state;
  const status = String(s.status || 'READY').toUpperCase();
  const scanning = status === 'SCANNING';
  const hasResults = Array.isArray(s.results) && s.results.length > 0;
  const hasAnything = hasResults || s.notExposedCount > 0;

  $('group-name').textContent = s.groupName || '—';
  $('group-name').title = s.groupName || '';
  $('participants-count').textContent = s.expectedTotal
    ? `${s.participantsScanned} / ${s.expectedTotal}`
    : String(s.participantsScanned || 0);
  $('numbers-count').textContent = String(s.numbersFound || 0);
  $('hidden-count').textContent = String(s.notExposedCount || 0);

  const badge = $('status-badge');
  badge.textContent = status;
  badge.className = 'badge badge-' + status.toLowerCase();

  const msg = $('message');
  msg.textContent = s.message || '';
  msg.className = 'message is-' + status.toLowerCase();

  renderProgress(s, scanning);

  $('scan-btn').disabled = scanning || view.tabId == null;
  $('stop-btn').disabled = !scanning;
  $('export-btn').disabled = !hasResults;
  $('clear-btn').disabled = scanning || !hasAnything;
  $('country-code').disabled = scanning;

  renderTable();
  renderHiddenList(s);
}

function renderProgress(s, scanning) {
  const wrap = $('progress');
  const bar = $('progress-bar');
  const fill = $('progress-fill');
  wrap.hidden = !scanning;
  if (!scanning) return;
  if (s.expectedTotal) {
    // "You" is not a scannable row, so the list holds expectedTotal - 1 others.
    const pct = Math.min(100, Math.round((s.participantsScanned / Math.max(1, s.expectedTotal - 1)) * 100));
    bar.classList.remove('indeterminate');
    bar.setAttribute('aria-valuenow', String(pct));
    fill.style.width = pct + '%';
  } else {
    bar.classList.add('indeterminate');
    bar.removeAttribute('aria-valuenow');
    fill.style.width = '';
  }
}

function visibleRecords(applyFilter = true) {
  const records = (view.state && view.state.results ? view.state.results : [])
    .map((r, i) => ({ index: i + 1, name: r.name || 'Unknown', phone: r.phone }));
  const q = applyFilter ? view.filter.trim().toLowerCase() : '';
  const qDigits = q.replace(/\D/g, '');
  const filtered = q
    ? records.filter((r) => r.name.toLowerCase().includes(q) ||
        r.phone.toLowerCase().includes(q) ||
        (qDigits.length >= 3 && r.phone.replace(/\D/g, '').includes(qDigits)))
    : records;

  const dir = view.sortDir;
  const collator = new Intl.Collator(undefined, { sensitivity: 'base', numeric: true });
  filtered.sort((a, b) => {
    if (view.sortKey === 'name') {
      // Keep "Unknown" at the bottom regardless of direction.
      const au = a.name === 'Unknown';
      const bu = b.name === 'Unknown';
      if (au !== bu) return au ? 1 : -1;
      return dir * collator.compare(a.name, b.name) || a.index - b.index;
    }
    if (view.sortKey === 'phone') return dir * collator.compare(a.phone, b.phone);
    return dir * (a.index - b.index);
  });
  return { filtered, total: records.length };
}

function renderTable() {
  const { filtered, total } = visibleRecords();
  const body = $('results-body');
  const frag = document.createDocumentFragment();
  filtered.forEach((r, i) => {
    const tr = document.createElement('tr');
    const idx = document.createElement('td');
    idx.className = 'idx';
    idx.textContent = String(i + 1);
    const name = document.createElement('td');
    name.textContent = r.name;
    if (r.name === 'Unknown') name.className = 'unknown';
    const phone = document.createElement('td');
    phone.className = 'phone';
    phone.textContent = r.phone;
    tr.append(idx, name, phone);
    frag.appendChild(tr);
  });
  body.replaceChildren(frag);

  $('result-count').textContent = view.filter.trim() ? `(${filtered.length} of ${total})` : `(${total})`;
  const empty = $('empty-state');
  empty.hidden = filtered.length > 0;
  if (total > 0 && filtered.length === 0) empty.textContent = 'No matches for your search.';
  else if (total === 0) empty.innerHTML = 'No results yet. Open a group in WhatsApp Web and click <strong>Scan Group</strong>.';

  document.querySelectorAll('thead th').forEach((th) => {
    const key = th.querySelector('button').dataset.sort;
    th.setAttribute('aria-sort', key === view.sortKey ? (view.sortDir === 1 ? 'ascending' : 'descending') : 'none');
  });
}

function renderHiddenList(s) {
  const names = Array.isArray(s.notExposedNames) ? s.notExposedNames : [];
  const details = $('hidden-details');
  details.hidden = names.length === 0;
  $('hidden-summary-count').textContent = String(names.length);
  const list = $('hidden-list');
  const frag = document.createDocumentFragment();
  names.forEach((n) => {
    const li = document.createElement('li');
    li.textContent = n;
    frag.appendChild(li);
  });
  list.replaceChildren(frag);
}

function showLocalMessage(status, text) {
  render({ ...(view.state || emptyState()), status, message: text });
}

/* ---------------- Actions ---------------- */

function readCountryCode() {
  const digits = $('country-code').value.replace(/\D/g, '').slice(0, 3);
  return /^[1-9]\d{0,2}$/.test(digits) ? digits : '';
}

async function onScan() {
  if (view.tabId == null) return showLocalMessage('ERROR', UI_TEXT.NOT_WHATSAPP);
  $('scan-btn').disabled = true;
  try {
    await ensureContentScript();
    const res = await sendToTab({ action: 'startScan', options: { defaultCountryCode: readCountryCode() } });
    render(res.state);
  } catch (_) {
    showLocalMessage('ERROR', UI_TEXT.NO_CONNECTION);
  }
}

async function onStop() {
  $('stop-btn').disabled = true;
  try {
    const res = await sendToTab({ action: 'stopScan' });
    render(res.state);
  } catch (_) {
    showLocalMessage('ERROR', UI_TEXT.NO_CONNECTION);
  }
}

function onExport() {
  const records = view.state && Array.isArray(view.state.results) ? view.state.results : [];
  if (!records.length) return showLocalMessage(view.state ? view.state.status : 'READY', UI_TEXT.NOTHING_TO_EXPORT);
  // Export every record in the current sort order; the search box never drops rows from the export.
  const ordered = visibleRecords(false).filtered.map((r) => ({ name: r.name, phone: r.phone }));
  downloadCsv(buildCsv(ordered), buildFilename(view.state.groupName));
}

async function onClear() {
  try {
    const res = await sendToTab({ action: 'clearResults' });
    view.filter = '';
    $('search').value = '';
    render(res.state);
  } catch (_) {
    render(emptyState());
  }
}

function onSort(event) {
  const button = event.target.closest('button[data-sort]');
  if (!button) return;
  const key = button.dataset.sort;
  if (view.sortKey === key) view.sortDir = -view.sortDir;
  else { view.sortKey = key; view.sortDir = 1; }
  renderTable();
}

function onRuntimeMessage(msg, sender) {
  if (msg && msg.type === 'scanUpdate' && sender.tab && sender.tab.id === view.tabId) {
    render(msg.state);
  }
}

function loadSettings() {
  try {
    $('country-code').value = localStorage.getItem(COUNTRY_CODE_KEY) || '';
  } catch (_) { /* storage unavailable — keep blank */ }
}

function saveSettings() {
  const cc = readCountryCode();
  $('country-code').value = cc;
  try {
    if (cc) localStorage.setItem(COUNTRY_CODE_KEY, cc);
    else localStorage.removeItem(COUNTRY_CODE_KEY);
  } catch (_) { /* ignore */ }
}

function bindEvents() {
  $('scan-btn').addEventListener('click', onScan);
  $('stop-btn').addEventListener('click', onStop);
  $('export-btn').addEventListener('click', onExport);
  $('clear-btn').addEventListener('click', onClear);
  $('search').addEventListener('input', (e) => { view.filter = e.target.value; renderTable(); });
  document.querySelector('thead').addEventListener('click', onSort);
  $('country-code').addEventListener('change', saveSettings);
}

async function init() {
  bindEvents();
  loadSettings();
  render(emptyState());

  let tab = null;
  try { tab = await getActiveTab(); } catch (_) { /* ignore */ }
  if (!tab || !isWhatsAppUrl(tab.url)) {
    view.tabId = null;
    return showLocalMessage('ERROR', UI_TEXT.NOT_WHATSAPP);
  }

  view.tabId = tab.id;
  chrome.runtime.onMessage.addListener(onRuntimeMessage);

  try {
    await ensureContentScript();
    const res = await sendToTab({ action: 'getState' });
    render(res.state);
    if (res.state && res.state.status === 'READY' && res.state.whatsappReady === false) {
      showLocalMessage('READY', 'WhatsApp Web is still loading.\nWait until your chats appear, then click Scan Group.');
    }
  } catch (_) {
    showLocalMessage('ERROR', UI_TEXT.NO_CONNECTION);
  }
}

document.addEventListener('DOMContentLoaded', init);
