# WhatsApp Group Number Extractor

A Chrome extension (Manifest V3) that reads the participant list of the WhatsApp group open in **WhatsApp Web** and lists the phone numbers WhatsApp Web actually shows. It removes duplicates and exports a CSV.

- Everything runs on your computer. Nothing is uploaded, there are no analytics, and the extension makes no network requests of its own.
- It reads only what WhatsApp Web has already drawn on screen. It doesn't use WhatsApp's private APIs, internal modules, IndexedDB, cookies, tokens or encryption keys.
- If WhatsApp Web shows only a name for someone (normally a contact saved in your phone), their number is reported as **"Phone number not exposed by WhatsApp Web."** The extension doesn't try to get around this.

---

## 1. Files

```text
whatsapp-group-number-extractor/
├── manifest.json     MV3 manifest (permissions: scripting + web.whatsapp.com only)
├── popup.html        Popup UI
├── popup.css         Popup styles
├── popup.js          Popup logic: status, table, search/sort, CSV export
├── content.js        Runs on WhatsApp Web: finds the panel, scrolls, extracts, deduplicates
├── icons/            16, 32, 48 and 128 px icons
├── README.md
└── LICENSE           MIT
```

### Why there is no `background.js`

A service worker isn't needed:

- The **content script** runs the scan and keeps the results in the WhatsApp tab's memory. The scan continues if the popup closes, and reopening the popup reloads the current state.
- The **popup** talks to the content script directly with `chrome.tabs.sendMessage`, and the content script sends progress back with `chrome.runtime.sendMessage`.
- The **CSV download** is a `data:` link in the popup, so the `downloads` permission and a background worker aren't needed.

With fewer parts and fewer permissions, there is less that can break and less to review.

### Permissions

| Permission | Why |
|---|---|
| `host_permissions: https://web.whatsapp.com/*` | Lets the content script run on WhatsApp Web, and nowhere else. |
| `scripting` | Injects `content.js` into a WhatsApp tab that was already open before the extension was installed or reloaded, so you don't have to refresh. |

`activeTab`, `downloads`, `storage` and `tabs` are **not** requested. The optional country-code setting is saved in the popup's own `localStorage`.

---

## 2. Install in Chrome (Load unpacked)

1. Unzip `whatsapp-group-number-extractor.zip` to a permanent folder, for example `Documents\Chrome Extensions\whatsapp-group-number-extractor`. Don't delete this folder afterwards, because Chrome loads the extension from it.
2. In Chrome, go to `chrome://extensions`.
3. Turn on **Developer mode** (top-right switch).
4. Click **Load unpacked** and select the folder that contains `manifest.json`.
5. Click the puzzle-piece icon on the toolbar, then **pin** "WhatsApp Group Number Extractor".
6. Microsoft Edge and Brave work the same way (`edge://extensions`, `brave://extensions`).

**To update:** replace the files in the folder, then click the reload icon on the extension's card in `chrome://extensions`.

---

## 3. How to use

1. Open **https://web.whatsapp.com** and log in.
2. Open the group.
3. Optional: open **Group info**. If you skip this, the extension clicks the chat header to open it.
4. Click the extension icon, then **Scan Group**.
   - If the group has more members than the panel shows, the extension clicks **"View all (N more)"** and scrolls the full list.
   - Keep the WhatsApp tab in front while the scan runs. In a background tab Chrome slows timers and the scan takes longer.
5. Watch the progress. Click **Stop** at any time; results found so far are kept.
6. Search, sort by name or phone, then click **Export CSV**.

**CSV format** (UTF-8 with BOM, so Hindi and other scripts display correctly in Excel):

```csv
Name,Phone Number
Rahul Sharma,+919876543210
Priya Mehta,+919812345678
```

The file is named `<Group-Name>-numbers-YYYY-MM-DD.csv`, for example `JPGS-Parents-numbers-2026-09-27.csv`, and falls back to `whatsapp-group-numbers-YYYY-MM-DD.csv`.

> **Excel tip:** if you double-click the CSV, Excel may show `+919876543210` as `9.19877E+11`. To keep the `+` and every digit, use **Data → From Text/CSV** and set the Phone Number column to **Text**. Google Sheets and LibreOffice (with "Detect special numbers" off) open the file as-is.

### Names

| What WhatsApp Web shows | Name in the results |
|---|---|
| Saved contact (name only, no number) | Listed under **Not Exposed**, not in the CSV |
| Unsaved contact: `+91 98765 43210` with `~ Rahul` | `Rahul` (their WhatsApp profile name) |
| Unsaved contact without a profile name | `Unknown` |

Names are never made up. When the same number appears more than once, the first meaningful name is kept.

### Settings: default country code

Leave this blank in normal use, because WhatsApp Web shows numbers in full international format (`+91 …`). Set it (for example `91`) only if numbers appear without a `+`. When it's blank, local numbers such as `09876543210` or `9876543210` are **rejected** rather than guessed. The one exception is a 12-digit `91XXXXXXXXXX` beginning with 91 and then 6–9, which is accepted as an Indian mobile.

---

## 4. Configuration (developers)

At the top of `content.js`:

```javascript
const DEBUG = false;          // true → prints scan progress to the WhatsApp tab's DevTools console
const CONFIG = {
  scrollDelay: 400,           // ms to wait for rendering after each scroll
  maxScanRounds: 250,         // hard stop; about 1,024 members at 4 rows per step
  maxIdleRounds: 5,           // rounds with nothing new at the end of the list before finishing
  scrollStepRatio: 0.8,
  domQuietMs: 120,
  panelWaitTimeout: 5000,
  updateThrottleMs: 250,
  autoOpenGroupInfo: true,
  autoOpenFullMemberList: true
};
```

Debug logging never prints messages, credentials or session data. It prints only counts, scroll positions and the element it chose.

On a slow computer or connection, raise `scrollDelay` to 700–1000.

---

## 5. Testing checklist

Run these on a real WhatsApp Web account before rolling the extension out to staff.

| # | Scenario | Steps | Expected result |
|---|---|---|---|
| 1 | Normal group | Open a group with unsaved members, then Scan | Numbers listed, status **COMPLETED** |
| 2 | Large group (100+) | Scan; watch it open "View all" and scroll | Participants count reaches about the member count minus 1 (you) |
| 3 | Duplicates | Look for a number listed twice | Appears once |
| 4 | Named participants | Unsaved contacts with a `~ Name` | That name is shown |
| 5 | No visible name | Unsaved contact without a profile name | `Unknown` |
| 6 | International | Group with +44, +1, +971 members | Stored as `+447911123456` and so on |
| 7 | No numbers visible | Group where every member is a saved contact | "No phone numbers were exposed by WhatsApp Web." |
| 8 | Stop | Click **Stop** mid-scan | "Scan stopped. N numbers found." Export still works |
| 9 | Not WhatsApp | Open the popup on any other site | "Please open WhatsApp Web first." Scan disabled |
| 10 | Private chat | Open a 1:1 chat, then Scan | "Please open a WhatsApp group first." |
| 11 | Still loading | Open the popup while the QR code or loading screen is shown | "WhatsApp Web is still loading…" |
| 12 | Refresh | Refresh WhatsApp Web, reopen the group, Scan | Works without reinstalling |

Also check: close the popup mid-scan and reopen it (progress continues); open the CSV in Excel and Google Sheets (Hindi names display correctly); **Clear Results** empties the table.

**Automated checks run on this build:** manifest JSON validation; `node --check` on both scripts; 23 phone-normalisation unit cases (every format in the spec, dates, times, message IDs, over-long strings, invalid Indian prefixes); and 33 end-to-end checks. The end-to-end checks loaded the unpacked extension in Chromium against a mock WhatsApp Web page with a virtualised 600-member list. They covered scenarios 1–12 above, CSV BOM and filename, search and sort, popup reopen, Clear, and safe re-injection of the content script.

---

## 6. Known limitations

1. **Only numbers WhatsApp Web displays can be extracted.** WhatsApp Web shows a saved contact by name only, so those numbers can't be captured. They're counted under **Not Exposed** and listed by name.
2. **WhatsApp Web changes its interface often.** The extension uses several fallback strategies (see section 7), but a large redesign can still break detection. You'll then see *"WhatsApp Web's interface may have changed…"* and the lookups in `content.js` need updating.
3. **English UI assumed** for text-based fallbacks such as "Group info", "members" and "View all". With WhatsApp set to another language, the structural strategies (ARIA roles, `data-testid`, hierarchy) still apply, but detection is less reliable. Switch WhatsApp to English if a scan fails.
4. **Your own number** ("You") is excluded, because WhatsApp doesn't show it in the list.
5. **Participants without numbers** are de-duplicated by name. Two saved contacts with the same display name count as one in *Not Exposed*. This doesn't affect exported numbers.
6. **Results live in the WhatsApp tab's memory.** Refreshing or closing the tab clears them, so export first.
7. **Very large groups**: `maxScanRounds` (250) covers about 1,000 members. If the limit is hit, the message says so. Raise the value for bigger communities.
8. **Background tab**: Chrome slows timers in hidden tabs, so a scan runs slower if you switch away. It still finishes.
9. **Chrome Web Store**: "WhatsApp" is a Meta trademark. For public publishing, rename the extension (for example "Group Contact Exporter for WhatsApp Web") and follow the Store's trademark and user-data policies. Loading it unpacked for internal use isn't affected.

---

## 7. WhatsApp Web DOM assumptions (update these if detection breaks)

All of these are in the `SEL` and `RE` objects near the top of `content.js`. Each lookup tries the strategies in order and moves to the next one if the first fails.

| What | Strategies, in order | Assumption that may change |
|---|---|---|
| App loaded | `#pane-side`, `[data-testid="chat-list"]`, `[aria-label="Chat list"]`; or `#main` | The chat list keeps the `#pane-side` id or an accessible "Chat list" label |
| Login / QR screen | `[data-ref] canvas`, `canvas[aria-label*="scan"]`, `[data-testid="qrcode"]` | The QR code is a canvas in a `data-ref` container |
| Open conversation | `#main`, `[data-testid="conversation-panel-wrapper"]` | The conversation pane keeps the `#main` id |
| Chat header / title | `header` inside `#main`; `[data-testid="conversation-info-header-chat-title"]`, `span[dir="auto"][title]` | The title is a `span[dir=auto]` with a `title` attribute |
| Group vs private chat | `data-icon*="default-group"` avatar; subtitle "click here for group info"; comma-separated names; private: "last seen", "online", "contact info" | Subtitle wording (English) |
| Group Info button | `[aria-label*="group info"]`, `[title*="group info"]`, `[data-testid="conversation-info-header"]`, then the title's `role=button` ancestor | Clicking the header opens Group Info |
| Group Info drawer | `[data-testid="chat-info-drawer"/"group-info-drawer"/"drawer-right"]`; text "N members" or "N participants"; heading "Group info"; then climbs to the drawer root (the outermost ancestor that doesn't contain `#main` or `#pane-side`) | The drawer is a sibling of `#main` and shows a member count |
| "View all" button | `role=button`, `button` or `[tabindex]` with text "View all…", "See all…" or "N more" | Large groups show only the first ~10 members in the drawer |
| Full member list | `[role="dialog"]`, `[data-animate-modal-popup]`, `[data-testid="popup-contents"]` that contains participant rows | "View all" opens a modal dialog |
| Participant rows | `[role="listitem"]`, `[data-testid="cell-frame-container"]`, `[role="row"]`; fallback: the clickable ancestor of `span[title]` | Rows keep an ARIA list role |
| Real participant vs action row | Has an avatar (`img`, `data-icon*="default-user"` and similar) or a phone number; excludes "Add member", "Invite via link", "Exit group", "View all" and similar | Avatar markup |
| Name / number in a row | First `[title]` or text is the primary line: a saved name, **or** the number for unsaved contacts; `~ Name` is the profile name; "You" is skipped | Unsaved contacts are shown as `+CC …` with `~ PushName` |
| Scroll container | Nearest scrollable ancestor of a row (`overflow-y: auto/scroll`), otherwise the largest scrollable element in the panel | The list scrolls inside its own container |
| Virtualised rendering | Sets `scrollTop`, dispatches a `scroll` event, then waits for the DOM to settle with a `MutationObserver` scoped to the list (disconnected after every step) | The list re-renders rows on scroll events |

**Fixing a broken selector:** in WhatsApp Web, right-click the element (a member row, the "View all" button, the Group Info panel) → **Inspect**. Look for a stable `data-testid`, `aria-label`, `role` or `title`, add it to the **front** of the matching `SEL` array in `content.js`, then reload the extension.

---

## 8. Privacy and responsible use

- Data is processed only in your browser tab. The extension makes no requests to any server and has no analytics or tracking.
- It never reads passwords, cookies, session tokens, IndexedDB, encryption keys or message contents. Text lookups skip the chat list and the open conversation.
- Exported CSVs contain personal data. Under India's **Digital Personal Data Protection Act, 2023**, use them only for the purpose members expect (for example, school–parent communication), store them securely, and delete them when they're no longer needed.
- WhatsApp's Terms of Service restrict automated or bulk collection of user data. Use the extension for occasional administrative exports of groups you manage, not for bulk harvesting or unsolicited messaging.

---

## 9. Troubleshooting

| Message | Fix |
|---|---|
| Please open WhatsApp Web first. | Switch to the `web.whatsapp.com` tab, then open the popup. |
| WhatsApp Web is still loading… | Wait for the chat list, or log in with the QR code. |
| Please open a WhatsApp group first. | Open a group, not a 1:1 chat. |
| Unable to locate the participant list. | Open **Group info** yourself and scroll to the members section, then Scan. |
| WhatsApp Web's interface may have changed. | Refresh WhatsApp Web. If it keeps happening, update the selectors (section 7). |
| Could not connect to WhatsApp Web. | Refresh the WhatsApp tab (needed after installing or reloading the extension if injection is blocked). |
