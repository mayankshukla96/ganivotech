/*
 * WhatsApp Group Number Extractor — content script
 *
 * Runs only on https://web.whatsapp.com/*. It reads what WhatsApp Web has
 * already rendered on screen (the group's participant list) and never touches
 * WhatsApp's internal modules, storage, IndexedDB, cookies, tokens or network
 * traffic. All results stay in this tab's memory until the popup exports them.
 *
 * WhatsApp Web changes its markup often, so every lookup below uses several
 * independent strategies (data-testid, ARIA, title attributes, visible text,
 * DOM hierarchy) instead of a single class name.
 */
(() => {
  'use strict';

  // If an older copy of this script is alive in this tab (extension reloaded
  // or script re-injected by the popup), shut it down before starting again.
  try {
    if (typeof window.__WGNE_DISPOSE__ === 'function') window.__WGNE_DISPOSE__();
  } catch (_) {
    /* the previous instance may belong to an unloaded extension — ignore */
  }

  /* ------------------------------------------------------------------ *
   * Configuration
   * ------------------------------------------------------------------ */

  const DEBUG = false;

  const CONFIG = {
    scrollDelay: 400,          // ms to wait for WhatsApp to render after each scroll
    maxScanRounds: 250,        // hard stop: ~250 scroll steps covers a 1,024-member group
    maxIdleRounds: 5,          // stop after this many rounds with no new participants at the end of the list
    scrollStepRatio: 0.8,      // scroll by 80% of the visible height so rows overlap between steps
    domQuietMs: 120,           // DOM considered "settled" after this long without mutations
    panelWaitTimeout: 5000,    // ms to wait for Group Info / member list to appear
    updateThrottleMs: 250,     // min gap between progress messages to the popup
    autoOpenGroupInfo: true,   // click the chat header to open Group Info if it is closed
    autoOpenFullMemberList: true // click "View all (N more)" to open the full member list
  };

  const STATUS = Object.freeze({
    READY: 'READY',
    SCANNING: 'SCANNING',
    COMPLETED: 'COMPLETED',
    STOPPED: 'STOPPED',
    ERROR: 'ERROR'
  });

  const MESSAGES = Object.freeze({
    READY: 'Ready',
    NOT_READY: 'WhatsApp Web is still loading or you are not logged in.\nWait until your chat list appears, then try again.',
    NO_GROUP: 'Please open a WhatsApp group first.',
    PANEL_NOT_FOUND: 'Unable to locate the participant list.\nPlease open Group Info and try again.',
    NO_NUMBERS: 'No phone numbers were exposed by WhatsApp Web.',
    UI_CHANGED: "WhatsApp Web's interface may have changed.\nPlease refresh WhatsApp Web and try again.",
    ALREADY_SCANNING: 'A scan is already running.',
    NOT_EXPOSED: 'Phone number not exposed by WhatsApp Web.'
  });

  /* ------------------------------------------------------------------ *
   * Selector strategies (ordered: most specific first, generic last)
   * ------------------------------------------------------------------ */

  const SEL = {
    chatList: ['#pane-side', '[data-testid="chat-list"]', '[aria-label="Chat list"]', '[aria-label*="chat list" i]'],
    loginScreen: ['[data-ref] canvas', 'canvas[aria-label*="scan" i]', '[data-testid="qrcode"]'],
    chatPane: ['#main', '[data-testid="conversation-panel-wrapper"]', '[data-testid="conversation-panel"]'],
    chatHeader: ['header', '[data-testid="conversation-header"]', '[role="banner"]'],
    chatTitle: [
      '[data-testid="conversation-info-header-chat-title"]',
      '[data-testid="conversation-title"]',
      'span[dir="auto"][title]',
      'span[dir="auto"]'
    ],
    groupInfoButton: [
      '[aria-label*="group info" i]',
      '[title*="group info" i]',
      '[aria-label*="profile details" i]',
      '[data-testid="conversation-info-header"]'
    ],
    drawers: [
      '[data-testid="chat-info-drawer"]',
      '[data-testid="group-info-drawer"]',
      '[data-testid="drawer-right"]',
      '[aria-label*="group info" i]'
    ],
    dialogs: ['[role="dialog"]', '[data-animate-modal-popup]', '[data-testid="popup-contents"]'],
    rows: ['[role="listitem"]', '[data-testid="cell-frame-container"]', '[role="row"]'],
    avatar: [
      'img',
      '[data-icon*="default-user"]',
      '[data-icon*="default-contact"]',
      '[data-testid*="default-user"]',
      '[data-testid*="avatar"]',
      '[data-icon*="person"]'
    ],
    groupAvatar: ['[data-icon*="default-group"]', '[data-testid*="default-group"]'],
    clickable: ['[role="button"]', 'button', '[tabindex]']
  };

  // Visible-text patterns (English UI). See README → "Selector assumptions".
  const RE = {
    memberCount: /(?:^|[·•|,]\s*)(\d[\d,.\u00A0\u202F ]*)\s+(members|participants)\b/i,
    groupInfoTitle: /^group info$/i,
    viewAll: /^(view all|see all)\b|^\d[\d,]*\s+more$/i,
    groupSubtitle: /(click|tap) (here )?for group info/i,
    privateSubtitle: /(click|tap) (here )?for contact info|last seen|^online$|^typing…?$/i,
    actionRow: /^(add members?|add participants?|invite (to group )?via link|invite link|exit group|leave group|report group|delete group|view all.*|see all.*|search members?)$/i,
    selfRow: /^you$/i,
    badge: /^(you|group admin|admin|community admin|~)$/i,
    memberDialogHint: /\b(members|participants)\b/i
  };

  const log = (...args) => {
    if (DEBUG) console.log('[WGNE]', ...args);
  };

  /* ------------------------------------------------------------------ *
   * Scan state (lives only in this tab's memory)
   * ------------------------------------------------------------------ */

  let status = STATUS.READY;
  let message = MESSAGES.READY;
  let groupName = '';
  let expectedTotal = null;
  let hitRoundLimit = false;
  let phoneIndex = new Map();        // normalized phone -> { name, phone }
  let seenParticipants = new Set();  // participant signatures already counted
  let notExposed = new Map();        // signature -> name (participants with no visible number)
  let abortController = null;
  let activeSignal = null;           // signal of the scan allowed to write results/status
  let lastPublishAt = 0;
  let publishTimer = null;

  function resetResults() {
    phoneIndex = new Map();
    seenParticipants = new Set();
    notExposed = new Map();
    expectedTotal = null;
    hitRoundLimit = false;
  }

  function snapshot() {
    return {
      status,
      message,
      groupName,
      expectedTotal,
      participantsScanned: seenParticipants.size,
      numbersFound: phoneIndex.size,
      notExposedCount: notExposed.size,
      notExposedNames: Array.from(notExposed.values()),
      results: Array.from(phoneIndex.values()),
      whatsappReady: isWhatsAppReady()
    };
  }

  function setStatus(nextStatus, nextMessage) {
    status = nextStatus;
    if (typeof nextMessage === 'string') message = nextMessage;
  }

  // Push state to the popup. Throttled so a fast scan cannot flood messaging.
  function publish(force = false) {
    const now = Date.now();
    const wait = CONFIG.updateThrottleMs - (now - lastPublishAt);
    if (!force && wait > 0) {
      if (!publishTimer) publishTimer = setTimeout(() => { publishTimer = null; publish(true); }, wait);
      return;
    }
    if (publishTimer) { clearTimeout(publishTimer); publishTimer = null; }
    lastPublishAt = now;
    try {
      if (!chrome.runtime || !chrome.runtime.id) {
        // Extension was reloaded/removed: this copy is orphaned. Stop quietly.
        if (abortController) abortController.abort();
        return;
      }
      const p = chrome.runtime.sendMessage({ type: 'scanUpdate', state: snapshot() });
      // No popup open → "Receiving end does not exist". That's expected.
      if (p && typeof p.catch === 'function') p.catch(() => {});
    } catch (_) {
      if (abortController) abortController.abort();
    }
  }

  /* ------------------------------------------------------------------ *
   * Generic DOM helpers
   * ------------------------------------------------------------------ */

  const cleanText = (s) => (s || '').replace(/[\s\u00A0\u202F\u200E\u200F]+/g, ' ').trim();
  const textOf = (el) => (el ? cleanText(el.textContent) : '');

  function queryFirst(root, selectors) {
    if (!root) return null;
    for (const selector of selectors) {
      try {
        const el = root.querySelector(selector);
        if (el) return el;
      } catch (_) { /* invalid selector in this browser — skip */ }
    }
    return null;
  }

  function queryAllUnique(root, selectors) {
    const found = new Set();
    if (!root) return [];
    for (const selector of selectors) {
      try {
        root.querySelectorAll(selector).forEach((el) => found.add(el));
      } catch (_) { /* skip */ }
    }
    return Array.from(found);
  }

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  // Keep only elements that are not nested inside another element of the list.
  function outermostOnly(elements) {
    return elements.filter((el) => !elements.some((other) => other !== el && other.contains(el)));
  }

  function leafTexts(root, limit = 40) {
    const out = [];
    if (!root) return out;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode()) && out.length < limit) {
      const t = cleanText(node.nodeValue);
      if (t) out.push(t);
    }
    return out;
  }

  /**
   * Find short text nodes matching `regex` outside the chat list and the open
   * conversation (so message text is never read). Returns their parent elements.
   */
  function findTextAnchors(regex, root = document.body, limit = 10) {
    const anchors = [];
    if (!root) return anchors;
    const excluded = new Set(
      [queryFirst(document, SEL.chatList), queryFirst(document, SEL.chatPane)].filter(Boolean)
    );
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (node.nodeType === Node.ELEMENT_NODE) {
          return excluded.has(node) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_SKIP;
        }
        const t = cleanText(node.nodeValue);
        return t && t.length <= 80 && regex.test(t) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
      }
    });
    let node;
    while ((node = walker.nextNode()) && anchors.length < limit) {
      if (node.parentElement) anchors.push(node.parentElement);
    }
    return anchors;
  }

  // Climb from an element to the outermost ancestor that still does not contain
  // the chat list or the conversation pane — i.e. the side drawer's root.
  function drawerRootFrom(el) {
    const chatList = queryFirst(document, SEL.chatList);
    const chatPane = queryFirst(document, SEL.chatPane);
    let current = el;
    while (current && current.parentElement && current.parentElement !== document.body) {
      const parent = current.parentElement;
      if ((chatList && parent.contains(chatList)) || (chatPane && parent.contains(chatPane))) break;
      if (current.matches && current.matches('[role="dialog"]')) break;
      current = parent;
    }
    return current;
  }

  function isScrollable(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return false;
    const overflowY = getComputedStyle(el).overflowY;
    return /(auto|scroll|overlay)/.test(overflowY) && el.scrollHeight > el.clientHeight + 4;
  }

  function sleep(ms, signal) {
    return new Promise((resolve) => {
      if (signal && signal.aborted) return resolve();
      const timer = setTimeout(done, ms);
      function done() {
        clearTimeout(timer);
        if (signal) signal.removeEventListener('abort', done);
        resolve();
      }
      if (signal) signal.addEventListener('abort', done, { once: true });
    });
  }

  /**
   * Resolve once `target` stops mutating for CONFIG.domQuietMs, or after
   * `timeoutMs`, or on abort. The observer is always disconnected.
   */
  function waitForDomSettle(target, timeoutMs, signal) {
    return new Promise((resolve) => {
      if (!target || (signal && signal.aborted)) return resolve(false);
      let quietTimer = null;
      let changed = false;
      const observer = new MutationObserver(() => {
        changed = true;
        clearTimeout(quietTimer);
        quietTimer = setTimeout(() => finish(true), CONFIG.domQuietMs);
      });
      const hardTimer = setTimeout(() => finish(changed), timeoutMs);
      function finish(result) {
        observer.disconnect();
        clearTimeout(quietTimer);
        clearTimeout(hardTimer);
        if (signal) signal.removeEventListener('abort', onAbort);
        resolve(result);
      }
      function onAbort() { finish(false); }
      if (signal) signal.addEventListener('abort', onAbort, { once: true });
      observer.observe(target, { childList: true, subtree: true, characterData: true });
    });
  }

  /**
   * Wait until `finder()` returns a truthy value. Uses a MutationObserver on
   * the app root, throttled, bounded by `timeoutMs`, and always disconnected.
   */
  function waitFor(finder, timeoutMs, signal) {
    return new Promise((resolve) => {
      const immediate = safeCall(finder);
      if (immediate || (signal && signal.aborted)) return resolve(immediate || null);
      const root = document.getElementById('app') || document.body;
      let throttle = null;
      const observer = new MutationObserver(() => {
        if (throttle) return;
        throttle = setTimeout(() => {
          throttle = null;
          const found = safeCall(finder);
          if (found) finish(found);
        }, 150);
      });
      const hardTimer = setTimeout(() => finish(safeCall(finder) || null), timeoutMs);
      function finish(value) {
        observer.disconnect();
        clearTimeout(throttle);
        clearTimeout(hardTimer);
        if (signal) signal.removeEventListener('abort', onAbort);
        resolve(value);
      }
      function onAbort() { finish(null); }
      if (signal) signal.addEventListener('abort', onAbort, { once: true });
      observer.observe(root, { childList: true, subtree: true });
    });
  }

  function safeCall(fn) {
    try { return fn(); } catch (err) { log('finder error', err); return null; }
  }

  function clickElement(el) {
    if (!el) return false;
    try {
      el.scrollIntoView({ block: 'nearest' });
      el.click();
      return true;
    } catch (_) {
      return false;
    }
  }

  /* ------------------------------------------------------------------ *
   * Phone number extraction & normalisation
   * ------------------------------------------------------------------ */

  // A run of digits with common separators, optionally starting with "+" or "(".
  // Look-arounds stop matches glued to letters, times (10:45), dates (27/09),
  // decimals or longer digit runs.
  const PHONE_CANDIDATE = /(?<![\w:/.+])(?:\+|00)?\(?\d[\d \-()\u00A0\u202F\u2011\u2012\u2013]{5,24}\d(?![\w:/.])/g;
  const DATE_LIKE = /^(\d{1,2}[-\s]\d{1,2}[-\s]\d{2,4}|\d{4}[-\s]\d{1,2}[-\s]\d{1,2})$/;

  function sanitizeCountryCode(value) {
    const digits = String(value || '').replace(/\D/g, '');
    return /^[1-9]\d{0,2}$/.test(digits) ? digits : '';
  }

  /**
   * Convert a raw match to E.164 (+<country><number>), or null if it does not
   * look like a real phone number.
   * @param {string} raw
   * @param {string} defaultCountryCode digits only, '' when unknown
   */
  function normalizePhone(raw, defaultCountryCode = '') {
    const trimmed = cleanText(raw);
    if (!trimmed || DATE_LIKE.test(trimmed)) return null;

    let digits = trimmed.replace(/\D/g, '');
    if (!digits || /^(\d)\1+$/.test(digits)) return null; // 0000000000 etc.

    let international = false;
    if (trimmed.startsWith('+')) {
      international = true;
    } else if (digits.startsWith('00')) {
      digits = digits.slice(2);
      international = true;
    }

    if (international) {
      // E.164: max 15 digits; shortest real numbers are ~8 with country code.
      if (digits.length < 8 || digits.length > 15 || digits[0] === '0') return null;
      if (digits.startsWith('91') && !/^91[6-9]\d{9}$/.test(digits)) return null; // Indian mobiles
      return '+' + digits;
    }

    const cc = sanitizeCountryCode(defaultCountryCode);

    // Bare "91XXXXXXXXXX" — unambiguous Indian mobile written without "+".
    if (/^91[6-9]\d{9}$/.test(digits)) return '+' + digits;

    if (!cc) return null; // Unknown country: never guess for local-format numbers.

    // Indian numbers can be validated strictly: 10-digit mobile starting 6–9.
    if (cc === '91') {
      const national = digits.replace(/^0/, '');
      return /^[6-9]\d{9}$/.test(national) ? '+91' + national : null;
    }

    // Number already carries the default country code, just without "+".
    if (digits.startsWith(cc) && digits.length - cc.length >= 8 && digits.length <= 15) return '+' + digits;

    const national = digits.replace(/^0/, ''); // strip trunk prefix, e.g. 07911… → 7911…
    const full = cc + national;
    if (national.length < 6 || full.length > 15) return null;
    return '+' + full;
  }

  /** Return all distinct valid phone numbers (E.164) found in `text`. */
  function extractPhoneNumbers(text, defaultCountryCode = '') {
    const results = [];
    if (!text) return results;
    const matches = String(text).match(PHONE_CANDIDATE) || [];
    for (const raw of matches) {
      const phone = normalizePhone(raw, defaultCountryCode);
      if (phone && !results.includes(phone)) results.push(phone);
    }
    return results;
  }

  /* ------------------------------------------------------------------ *
   * WhatsApp Web structure detection
   * ------------------------------------------------------------------ */

  function isWhatsAppReady() {
    return !!(queryFirst(document, SEL.chatList) || queryFirst(document, SEL.chatPane));
  }

  function findChatPane() {
    return queryFirst(document, SEL.chatPane);
  }

  function findGroupHeader() {
    const pane = findChatPane();
    return pane ? queryFirst(pane, SEL.chatHeader) : null;
  }

  function findHeaderTitleElement(header) {
    if (!header) return null;
    for (const selector of SEL.chatTitle) {
      let candidates = [];
      try { candidates = Array.from(header.querySelectorAll(selector)); } catch (_) { continue; }
      const el = candidates.find((c) => cleanText(c.getAttribute('title') || c.textContent));
      if (el) return el;
    }
    return null;
  }

  function readGroupName(header, panel) {
    const titleEl = findHeaderTitleElement(header);
    const fromHeader = titleEl ? cleanText(titleEl.getAttribute('title') || titleEl.textContent) : '';
    if (fromHeader) return fromHeader;
    if (panel) {
      const t = leafTexts(panel, 15).find((s) =>
        !RE.groupInfoTitle.test(s) && !RE.memberCount.test(s) && s.length <= 100 && !/^(close|search|×)$/i.test(s));
      if (t) return t;
    }
    return '';
  }

  /** 'group' | 'private' | 'unknown', based on header signals only. */
  function classifyHeader(header) {
    if (!header) return 'unknown';
    if (queryFirst(header, SEL.groupAvatar)) return 'group';
    const titleEl = findHeaderTitleElement(header);
    const title = titleEl ? cleanText(titleEl.getAttribute('title') || titleEl.textContent) : '';
    const others = [
      ...Array.from(header.querySelectorAll('[title]')).map((e) => cleanText(e.getAttribute('title'))),
      ...leafTexts(header, 20)
    ].filter((t) => t && t !== title);
    if (others.some((t) => RE.groupSubtitle.test(t))) return 'group';
    if (others.some((t) => RE.privateSubtitle.test(t))) return 'private';
    if (others.some((t) => t.split(',').length >= 3)) return 'group'; // "Rahul, Priya, You"
    return 'unknown';
  }

  function findGroupInfoButton(header) {
    if (!header) return null;
    const direct = queryFirst(header, SEL.groupInfoButton);
    if (direct) return direct;
    const titleEl = findHeaderTitleElement(header);
    return titleEl ? (titleEl.closest('[role="button"]') || titleEl) : null;
  }

  function parseMemberCount(root) {
    if (!root) return null;
    for (const t of leafTexts(root, 200)) {
      const m = t.match(RE.memberCount);
      if (m) {
        const n = parseInt(m[1].replace(/\D/g, ''), 10);
        if (Number.isFinite(n) && n > 0) return n;
      }
    }
    return null;
  }

  function looksLikeMemberDrawer(el) {
    if (!el || !isVisible(el)) return false;
    return RE.memberCount.test(el.textContent || '') ||
      leafTexts(el, 10).some((t) => RE.groupInfoTitle.test(t));
  }

  /** The Group Info side drawer, or null. */
  function findInfoDrawer() {
    for (const el of queryAllUnique(document, SEL.drawers)) {
      if (looksLikeMemberDrawer(el)) return el;
    }
    for (const anchor of findTextAnchors(RE.memberCount)) {
      if (anchor.closest('[role="dialog"]')) continue;
      const root = drawerRootFrom(anchor);
      if (root && isVisible(root)) return root;
    }
    for (const anchor of findTextAnchors(RE.groupInfoTitle)) {
      const root = drawerRootFrom(anchor);
      if (root && isVisible(root) && getParticipantRows(root).length) return root;
    }
    return null;
  }

  /**
   * The full "View all" member list dialog, or null.
   * @param {boolean} openedByUs accept any visible dialog with participant rows
   */
  function findMemberDialog(openedByUs = false) {
    for (const dialog of queryAllUnique(document, SEL.dialogs)) {
      if (!isVisible(dialog)) continue;
      const hasHint = openedByUs || RE.memberDialogHint.test(dialog.textContent || '') ||
        !!dialog.querySelector('input[placeholder*="member" i], [aria-label*="member" i]');
      if (hasHint && getParticipantRows(dialog).length) return dialog;
    }
    return null;
  }

  /** { el, kind: 'dialog' | 'drawer' } or null. */
  function findParticipantPanel() {
    const dialog = findMemberDialog(false);
    if (dialog) return { el: dialog, kind: 'dialog' };
    const drawer = findInfoDrawer();
    if (drawer) return { el: drawer, kind: 'drawer' };
    return null;
  }

  function findViewAllButton(panel) {
    if (!panel) return null;
    for (const el of queryAllUnique(panel, SEL.clickable)) {
      const t = textOf(el);
      if (t && t.length <= 40 && RE.viewAll.test(t)) return el;
    }
    const anchor = findTextAnchors(RE.viewAll, panel, 1)[0];
    return anchor ? (anchor.closest('[role="button"], button, [tabindex]') || anchor) : null;
  }

  function isParticipantRow(row) {
    const t = textOf(row);
    if (!t || t.length > 500) return false;
    if (RE.actionRow.test(t)) return false;
    if (queryFirst(row, SEL.avatar)) return true;
    return extractPhoneNumbers(t).length > 0;
  }

  function getParticipantRows(container) {
    if (!container) return [];
    let rows = queryAllUnique(container, SEL.rows);
    if (!rows.length) {
      // Fallback: rows are the clickable blocks that hold a titled span.
      rows = Array.from(new Set(
        Array.from(container.querySelectorAll('span[title]'))
          .map((s) => s.closest('[role="button"], [tabindex="-1"], [tabindex="0"]'))
          .filter(Boolean)
      ));
    }
    return outermostOnly(rows).filter(isParticipantRow);
  }

  function findParticipantScrollContainer(panel, sampleRow) {
    if (!panel) return null;
    for (let el = sampleRow ? sampleRow.parentElement : null; el && el !== document.body; el = el.parentElement) {
      if (isScrollable(el)) return el;
      if (el === panel) break;
    }
    let best = null;
    panel.querySelectorAll('div, section').forEach((el) => {
      if (isScrollable(el) && (!best || el.scrollHeight > best.scrollHeight)) best = el;
    });
    if (!best && isScrollable(panel)) best = panel;
    return best;
  }

  /**
   * Read one participant row.
   * WhatsApp layout: the primary line is the saved contact name OR, for
   * unsaved contacts, the phone number (with "~ PushName" alongside).
   * @returns {{self:boolean,name:string,phone:string|null,signature:string}|null}
   */
  function extractParticipantFromElement(row, defaultCountryCode) {
    const titled = Array.from(row.querySelectorAll('[title]'))
      .map((e) => cleanText(e.getAttribute('title')))
      .filter(Boolean);
    const pieces = Array.from(new Set([...titled, ...leafTexts(row, 30)]));
    if (!pieces.length) return null;

    const primary = pieces.find((p) => p !== '~' && !/^group admin$|^admin$/i.test(p)) || pieces[0];
    if (RE.selfRow.test(primary)) return { self: true, name: 'You', phone: null, signature: 'self' };

    let phone = null;
    for (const piece of pieces) {
      const found = extractPhoneNumbers(piece, defaultCountryCode);
      if (found.length) { phone = found[0]; break; }
    }
    if (!phone) {
      const aria = row.getAttribute('aria-label');
      const found = aria ? extractPhoneNumbers(aria, defaultCountryCode) : [];
      if (found.length) phone = found[0];
    }

    const primaryIsPhone = extractPhoneNumbers(primary, defaultCountryCode).length > 0;
    const pushName = pieces
      .map((p) => (/^~\s*\S/.test(p) ? cleanText(p.replace(/^~\s*/, '')) : ''))
      .find(Boolean);
    let name = !primaryIsPhone && !RE.badge.test(primary) ? primary : (pushName || 'Unknown');
    if (name.length > 100) name = name.slice(0, 100);

    const signature = phone ? 'p:' + phone : 'n:' + name + '|' + (pieces[1] || '');
    return { self: false, name, phone, signature };
  }

  /** Extract all currently rendered participant rows. Returns number of new participants. */
  function harvest(panel, defaultCountryCode) {
    let added = 0;
    for (const row of getParticipantRows(panel)) {
      const info = extractParticipantFromElement(row, defaultCountryCode);
      if (!info || info.self || seenParticipants.has(info.signature)) continue;
      seenParticipants.add(info.signature);
      added++;
      if (info.phone) {
        const existing = phoneIndex.get(info.phone);
        if (!existing) phoneIndex.set(info.phone, { name: info.name, phone: info.phone });
        else if (existing.name === 'Unknown' && info.name !== 'Unknown') existing.name = info.name;
      } else {
        notExposed.set(info.signature, info.name);
      }
    }
    return added;
  }

  /* ------------------------------------------------------------------ *
   * Scan workflow
   * ------------------------------------------------------------------ */

  // A scan that was cancelled by "Clear Results" must not overwrite the cleared state.
  const isCurrent = (signal) => signal === activeSignal;

  function fail(msgText, signal) {
    if (signal && !isCurrent(signal)) return;
    setStatus(STATUS.ERROR, msgText);
    publish(true);
  }

  function progressMessage() {
    const total = expectedTotal ? ` of ~${expectedTotal}` : '';
    return `Scanning participants…\nParticipants scanned: ${seenParticipants.size}${total}\nNumbers found: ${phoneIndex.size}`;
  }

  async function scrollAndHarvest(panel, cc, signal) {
    let rows = getParticipantRows(panel);
    if (!rows.length) {
      rows = (await waitFor(() => {
        const r = getParticipantRows(panel);
        return r.length ? r : null;
      }, 2000, signal)) || [];
    }
    const scroller = findParticipantScrollContainer(panel, rows[0]);
    log('scroll container', scroller);

    if (scroller && scroller.scrollTop > 0) {
      scroller.scrollTop = 0;
      await waitForDomSettle(scroller, CONFIG.scrollDelay, signal);
    }

    let idleRounds = 0;
    for (let round = 0; round < CONFIG.maxScanRounds; round++) {
      if (signal.aborted) return;
      if (!panel.isConnected) break; // user closed the panel

      const added = harvest(panel, cc);
      message = progressMessage();
      publish();

      if (!scroller || !scroller.isConnected) {
        // Nothing to scroll: take a second look after the DOM settles, then stop.
        if (round > 0) break;
        await waitForDomSettle(panel, CONFIG.scrollDelay, signal);
        continue;
      }

      const before = scroller.scrollTop;
      const step = Math.max(40, Math.floor(scroller.clientHeight * CONFIG.scrollStepRatio));
      scroller.scrollTop = before + step;
      // Browsers deliver the native scroll event on the next animation frame,
      // which is paused in background tabs. Dispatching one now lets
      // WhatsApp's virtualised list render the new rows either way.
      scroller.dispatchEvent(new Event('scroll', { bubbles: true }));
      await waitForDomSettle(scroller, CONFIG.scrollDelay, signal);

      const moved = Math.abs(scroller.scrollTop - before) > 1;
      log('round', round, 'added', added, 'top', before, '->', scroller.scrollTop, 'h', scroller.scrollHeight, 'seen', seenParticipants.size);
      const atBottom = scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4;
      if (added === 0 && (!moved || atBottom)) idleRounds++;
      else if (added > 0) idleRounds = 0;
      if (idleRounds >= CONFIG.maxIdleRounds) {
        harvest(panel, cc); // final pass on the last screen
        return;
      }
      if (round === CONFIG.maxScanRounds - 1) hitRoundLimit = true;
    }
  }

  function finishScan(signal) {
    if (!isCurrent(signal)) return;
    const n = phoneIndex.size;
    const hidden = notExposed.size;
    const hiddenNote = hidden
      ? `\n${hidden} participant${hidden === 1 ? '' : 's'}: ${MESSAGES.NOT_EXPOSED}`
      : '';

    if (signal.aborted) {
      setStatus(STATUS.STOPPED, `Scan stopped.\n${n} number${n === 1 ? '' : 's'} found.${hiddenNote}`);
    } else if (seenParticipants.size === 0) {
      setStatus(STATUS.ERROR, expectedTotal ? MESSAGES.UI_CHANGED : MESSAGES.PANEL_NOT_FOUND);
    } else if (n === 0) {
      setStatus(STATUS.COMPLETED, MESSAGES.NO_NUMBERS + hiddenNote);
    } else {
      const limitNote = hitRoundLimit ? '\nScan limit reached — the list may be incomplete. Run again to continue.' : '';
      setStatus(STATUS.COMPLETED,
        `Scan complete.\n${n} number${n === 1 ? '' : 's'} found from ${seenParticipants.size} participants.${hiddenNote}${limitNote}`);
    }
    publish(true);
  }

  async function runScan(options, signal) {
    const cc = sanitizeCountryCode(options && options.defaultCountryCode);

    if (!isWhatsAppReady() || queryFirst(document, SEL.loginScreen)) return fail(MESSAGES.NOT_READY, signal);

    const header = findGroupHeader();
    let found = findParticipantPanel();

    if (!found) {
      if (!header) return fail(MESSAGES.NO_GROUP, signal);
      const kind = classifyHeader(header);
      log('header kind', kind);
      if (CONFIG.autoOpenGroupInfo) {
        setStatus(STATUS.SCANNING, 'Opening Group Info…');
        publish(true);
        clickElement(findGroupInfoButton(header));
        found = await waitFor(findParticipantPanel, CONFIG.panelWaitTimeout, signal);
      }
      if (signal.aborted) return finishScan(signal);
      if (!found) {
        if (kind === 'group') return fail(MESSAGES.PANEL_NOT_FOUND, signal);
        if (kind === 'private') return fail(MESSAGES.NO_GROUP, signal);
        return fail(`${MESSAGES.NO_GROUP}\nIf a group is already open, open Group Info and try again.`, signal);
      }
    }

    let panel = found.el;
    groupName = readGroupName(header, found.kind === 'drawer' ? panel : null);
    expectedTotal = parseMemberCount(panel);

    if (found.kind === 'drawer' && CONFIG.autoOpenFullMemberList) {
      const viewAll = findViewAllButton(panel);
      if (viewAll) {
        setStatus(STATUS.SCANNING, 'Opening full member list…');
        publish(true);
        clickElement(viewAll);
        const dialog = await waitFor(() => findMemberDialog(true), CONFIG.panelWaitTimeout, signal);
        if (dialog) panel = dialog;
        else await waitForDomSettle(panel, CONFIG.scrollDelay, signal); // list may have expanded inline
      }
    }
    if (signal.aborted) return finishScan(signal);

    setStatus(STATUS.SCANNING, progressMessage());
    publish(true);
    await scrollAndHarvest(panel, cc, signal);
    finishScan(signal);
  }

  function startScan(options) {
    resetResults();
    groupName = '';
    abortController = new AbortController();
    const signal = abortController.signal;
    activeSignal = signal;
    setStatus(STATUS.SCANNING, 'Preparing scan…');
    publish(true);
    runScan(options || {}, signal)
      .catch((err) => {
        log('scan failed', err);
        fail(MESSAGES.UI_CHANGED, signal);
      })
      .finally(() => {
        if (abortController && abortController.signal === signal) abortController = null;
      });
  }

  function stopScan() {
    if (abortController) abortController.abort();
  }

  /* ------------------------------------------------------------------ *
   * Messaging with the popup
   * ------------------------------------------------------------------ */

  function onMessage(msg, _sender, sendResponse) {
    if (!msg || typeof msg.action !== 'string') return false;
    try {
      switch (msg.action) {
        case 'ping':
          sendResponse({ ok: true, ready: isWhatsAppReady() });
          break;
        case 'getState':
          if (status === STATUS.READY) groupName = readGroupName(findGroupHeader(), null);
          sendResponse({ ok: true, state: snapshot() });
          break;
        case 'startScan':
          if (status === STATUS.SCANNING && abortController) {
            sendResponse({ ok: false, error: MESSAGES.ALREADY_SCANNING, state: snapshot() });
          } else {
            startScan(msg.options);
            sendResponse({ ok: true, state: snapshot() });
          }
          break;
        case 'stopScan':
          stopScan();
          sendResponse({ ok: true, state: snapshot() });
          break;
        case 'clearResults':
          stopScan();
          activeSignal = null; // detach the cancelled scan so it cannot write results
          resetResults();
          setStatus(STATUS.READY, MESSAGES.READY);
          groupName = readGroupName(findGroupHeader(), null);
          sendResponse({ ok: true, state: snapshot() });
          break;
        default:
          return false;
      }
    } catch (err) {
      log('message handler error', err);
      sendResponse({ ok: false, error: MESSAGES.UI_CHANGED });
    }
    return false; // all responses above are synchronous
  }

  chrome.runtime.onMessage.addListener(onMessage);

  window.__WGNE_DISPOSE__ = () => {
    stopScan();
    try { chrome.runtime.onMessage.removeListener(onMessage); } catch (_) { /* orphaned */ }
  };

  log('content script ready');
})();
