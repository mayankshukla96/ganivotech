const SITE = "https://ganivotech.com";
const $ = (id) => document.getElementById(id);
const utm = (path, campaign) => `${SITE}${path}?utm_source=chrome-extension&utm_medium=extension&utm_campaign=${campaign}`;

function toast(msg) {
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 1700);
}

function download(blob, name) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

const copy = (text, msg = "Copied") => navigator.clipboard.writeText(text).then(() => toast(msg));

// footer / promo links carry UTM tags so the site's analytics can show extension traffic
$("link-site").href = utm("/", "footer");
$("link-privacy").href = utm("/privacy", "footer");
$("link-qr").href = utm("/tools/qr-generator", "qr-tab");

// ---------------- tabs ----------------
document.querySelectorAll(".tab").forEach((tab) =>
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((t) => {
      t.classList.toggle("active", t === tab);
      t.setAttribute("aria-selected", t === tab);
    });
    document.querySelectorAll(".panel").forEach((p) => p.classList.toggle("active", p.id === `panel-${tab.dataset.tab}`));
  })
);

function pickChip(container, attr, value) {
  container.querySelectorAll(".chip[data-" + attr + "]").forEach((c) => c.classList.toggle("on", c.dataset[attr] === value));
}

// ---------------- QR ----------------
const STYLES = {
  Brand: { fg: "#0f3d8c", fg2: "#f59e0b", bg: "#ffffff", pattern: "rounded", eye: "rounded" },
  Classic: { fg: "#000000", fg2: null, bg: "#ffffff", pattern: "square", eye: "square" },
  Ocean: { fg: "#0369a1", fg2: "#0d9488", bg: "#ffffff", pattern: "rounded", eye: "rounded" },
};
const qr = { src: "page", style: "Brand", pageUrl: "", pageTitle: "", logo: null, svg: "" };

function currentText() {
  return qr.src === "page" ? qr.pageUrl : $("qr-text").value.trim();
}

function renderQR() {
  const text = currentText();
  const img = $("qr-img");
  if (!text) {
    img.hidden = true;
    qr.svg = "";
    $("qr-msg").textContent = qr.src === "page" ? "This page cannot be turned into a QR code. Use Text / link instead." : "Type a link or text to make a QR code.";
  } else {
    try {
      const useLogo = $("qr-logo").checked && qr.logo;
      qr.svg = GTQR.build(text, { ...STYLES[qr.style], margin: 3, logo: useLogo ? qr.logo : null, size: 1000 });
      img.src = GTQR.toDataUrl(qr.svg);
      img.hidden = false;
      $("qr-msg").textContent = "";
    } catch {
      img.hidden = true;
      qr.svg = "";
      $("qr-msg").textContent = "Too much text for one QR code. Please shorten it.";
    }
  }
  ["qr-png", "qr-svg", "qr-copy"].forEach((id) => ($(id).disabled = !qr.svg));
}

async function loadLogo() {
  try {
    const blob = await (await fetch(chrome.runtime.getURL("icons/logo.jpg"))).blob();
    const bmp = await createImageBitmap(blob);
    const c = document.createElement("canvas");
    c.width = c.height = 160;
    c.getContext("2d").drawImage(bmp, 0, 0, 160, 160);
    qr.logo = c.toDataURL("image/png");
  } catch {}
}

$("qr-source").addEventListener("click", (e) => {
  const b = e.target.closest("[data-src]");
  if (!b) return;
  qr.src = b.dataset.src;
  pickChip($("qr-source"), "src", qr.src);
  $("qr-text").classList.toggle("hidden", qr.src !== "text");
  $("qr-page-info").classList.toggle("hidden", qr.src !== "page");
  renderQR();
});
$("qr-style").addEventListener("click", (e) => {
  const b = e.target.closest("[data-style]");
  if (!b) return;
  qr.style = b.dataset.style;
  pickChip($("qr-style"), "style", qr.style);
  renderQR();
});
$("qr-logo").addEventListener("change", renderQR);
$("qr-text").addEventListener("input", renderQR);

$("qr-png").addEventListener("click", async () => download(await GTQR.toPngBlob(qr.svg, 1000), "ganivotech-qr.png"));
$("qr-svg").addEventListener("click", () => download(new Blob([qr.svg], { type: "image/svg+xml" }), "ganivotech-qr.svg"));
$("qr-copy").addEventListener("click", async () => {
  try {
    await navigator.clipboard.write([new ClipboardItem({ "image/png": await GTQR.toPngBlob(qr.svg, 600) })]);
    toast("QR image copied");
  } catch {
    toast("Could not copy. Use Download.");
  }
});

(async function initQR() {
  await loadLogo();
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && /^https?:\/\//i.test(tab.url || "")) {
      qr.pageUrl = tab.url;
      qr.pageTitle = tab.title || "";
      $("qr-page-info").textContent = `${qr.pageTitle ? qr.pageTitle + " - " : ""}${tab.url}`;
      $("qr-page-info").title = tab.url;
    } else {
      $("qr-page-info").textContent = "This kind of page cannot be shared as a link.";
    }
  } catch {}
  renderQR();
})();

// ---------------- Scan ----------------
const MAX_SIDE = 3000;

function imageToCanvas(img) {
  const s = Math.min(1, MAX_SIDE / Math.max(img.naturalWidth || img.width, img.naturalHeight || img.height));
  const c = document.createElement("canvas");
  c.width = Math.round((img.naturalWidth || img.width) * s);
  c.height = Math.round((img.naturalHeight || img.height) * s);
  const ctx = c.getContext("2d", { willReadFrequently: true });
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.drawImage(img, 0, 0, c.width, c.height);
  return c;
}

const loadImg = (src) => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });

function el(tag, text, cls) {
  const e = document.createElement(tag);
  if (text != null) e.textContent = text;
  if (cls) e.className = cls;
  return e;
}

function showResults(codes) {
  const box = $("scan-results");
  box.replaceChildren();
  if (!codes.length) {
    $("scan-status").textContent = "No QR code found. Make sure the whole code is visible and not too small.";
    return;
  }
  $("scan-status").textContent = codes.length === 1 ? "1 QR code found" : `${codes.length} QR codes found`;
  codes.forEach((text) => {
    const d = GTScan.describe(text);
    const card = el("div", null, "result");
    card.append(el("h3", d.kind));
    const dl = el("dl");
    d.rows.forEach(([k, v]) => { dl.append(el("dt", k), el("dd", v)); });
    card.append(dl);
    d.warnings.forEach((w) => card.append(el("div", w, "warn")));
    const acts = el("div", null, "acts");
    d.actions.forEach((a) => {
      const b = el("button", a.label, a.type === "open" ? "btn-primary" : "btn-dark");
      b.style.width = "auto";
      b.addEventListener("click", () => {
        if (a.type === "copy") copy(a.value);
        else if (a.type === "open") chrome.tabs.create({ url: a.value });
        else download(new Blob([a.value], { type: a.mime }), a.filename);
      });
      acts.append(b);
    });
    card.append(acts);
    box.append(card);
  });
}

function scanImage(img) {
  const codes = GTScan.scanCanvas(imageToCanvas(img), jsQR);
  showResults(codes);
}

$("scan-btn").addEventListener("click", async () => {
  $("scan-status").textContent = "Scanning...";
  $("scan-results").replaceChildren();
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: "png" });
    scanImage(await loadImg(dataUrl));
  } catch {
    $("scan-status").textContent = "Chrome does not allow scanning this page (for example chrome:// pages). Open a normal website, or drop an image below.";
  }
});

async function scanFile(file) {
  if (!file || !file.type.startsWith("image/")) return;
  $("scan-status").textContent = "Scanning...";
  const url = URL.createObjectURL(file);
  try {
    scanImage(await loadImg(url));
  } catch {
    $("scan-status").textContent = "Could not read that image.";
  } finally {
    URL.revokeObjectURL(url);
  }
}

$("scan-file").addEventListener("change", (e) => scanFile(e.target.files[0]));
const drop = $("scan-drop");
["dragenter", "dragover"].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add("over"); }));
["dragleave", "drop"].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove("over"); }));
drop.addEventListener("drop", (e) => scanFile(e.dataTransfer.files[0]));
drop.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $("scan-file").click(); } });
document.addEventListener("paste", (e) => {
  const f = [...(e.clipboardData?.files || [])].find((x) => x.type.startsWith("image/"));
  if (f) {
    document.querySelector('[data-tab="scan"]').click();
    scanFile(f);
  }
});

// ---------------- Tools ----------------
$("tool-pick").addEventListener("click", (e) => {
  const b = e.target.closest("[data-tool]");
  if (!b) return;
  pickChip($("tool-pick"), "tool", b.dataset.tool);
  document.querySelectorAll(".tool").forEach((t) => t.classList.toggle("hidden", t.id !== `tool-${b.dataset.tool}`));
});

// password: unbiased random picks, at least one character from every ticked set
function randInt(max) {
  const lim = Math.floor(0x100000000 / max) * max;
  let x;
  do { x = crypto.getRandomValues(new Uint32Array(1))[0]; } while (x >= lim);
  return x % max;
}
$("pw-length").addEventListener("input", () => ($("pw-len-val").textContent = $("pw-length").value));
$("pw-btn").addEventListener("click", () => {
  const sets = [
    $("pw-upper").checked && "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    $("pw-lower").checked && "abcdefghijklmnopqrstuvwxyz",
    $("pw-digits").checked && "0123456789",
    $("pw-symbols").checked && "!@#$%^&*()-_=+[]{};:,.?",
  ].filter(Boolean);
  if (!sets.length) sets.push("abcdefghijklmnopqrstuvwxyz0123456789");
  const len = +$("pw-length").value;
  const all = sets.join("");
  const out = sets.map((s) => s[randInt(s.length)]);
  while (out.length < len) out.push(all[randInt(all.length)]);
  for (let i = out.length - 1; i > 0; i--) { const j = randInt(i + 1); [out[i], out[j]] = [out[j], out[i]]; }
  $("pw-output").value = out.join("");
  const el = $("pw-strength");
  const bits = len * Math.log2(all.length);
  el.className = "strength " + (bits < 60 ? "weak" : bits < 90 ? "medium" : "strong");
  el.textContent = bits < 60 ? "Weak" : bits < 90 ? "Good" : "Strong";
});
$("pw-copy").addEventListener("click", () => $("pw-output").value && copy($("pw-output").value, "Password copied"));
$("pw-btn").click();

// JSON
function jsonRun(pretty) {
  const err = $("json-error");
  err.textContent = "";
  try {
    const v = JSON.parse($("json-input").value);
    $("json-input").value = pretty ? JSON.stringify(v, null, 2) : JSON.stringify(v);
  } catch (e) {
    err.textContent = "Invalid JSON: " + e.message;
  }
}
$("json-format").addEventListener("click", () => jsonRun(true));
$("json-minify").addEventListener("click", () => jsonRun(false));
$("json-copy").addEventListener("click", () => $("json-input").value && copy($("json-input").value, "JSON copied"));

// colour picker (+ screen eyedropper)
function renderColor(hex) {
  const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
  const mx = Math.max(r, g, b) / 255, mn = Math.min(r, g, b) / 255, l = (mx + mn) / 2, d = mx - mn;
  let h = 0, s = 0;
  if (d) {
    s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    const rn = r / 255, gn = g / 255, bn = b / 255;
    h = mx === rn ? ((gn - bn) / d + (gn < bn ? 6 : 0)) : mx === gn ? (bn - rn) / d + 2 : (rn - gn) / d + 4;
    h *= 60;
  }
  const vals = [["HEX", hex], ["RGB", `rgb(${r}, ${g}, ${b})`], ["HSL", `hsl(${Math.round(h)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`]];
  const box = $("color-values");
  box.replaceChildren();
  vals.forEach(([k, v]) => {
    const b2 = el("button", null);
    b2.append(el("span", k), el("span", v));
    b2.addEventListener("click", () => copy(v, `${k} copied`));
    box.append(b2);
  });
}
$("color-input").addEventListener("input", (e) => renderColor(e.target.value));
$("eyedrop").addEventListener("click", async () => {
  if (!window.EyeDropper) return toast("Eyedropper not supported");
  try {
    const { sRGBHex } = await new EyeDropper().open();
    $("color-input").value = sRGBHex;
    renderColor(sRGBHex);
  } catch {}
});
renderColor($("color-input").value);

// ---------------- Suggest ----------------
async function loadSent() {
  const { sent = [] } = await chrome.storage.local.get("sent");
  const ul = $("suggest-list");
  ul.replaceChildren();
  sent.slice(0, 3).forEach((s) => ul.append(el("li", `Sent: ${s}`)));
}
$("suggest-btn").addEventListener("click", async () => {
  const idea = $("suggest-idea").value.trim();
  const msg = $("suggest-msg");
  msg.className = "muted center";
  if (idea.length < 5) { msg.textContent = "Please describe your idea in a few words."; return; }
  $("suggest-btn").disabled = true;
  msg.textContent = "Sending...";
  try {
    const r = await fetch(`${SITE}/api/suggest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: $("suggest-name").value, idea, source: "chrome-extension" }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.ok) throw new Error(j.error || "Could not send. Please try again.");
    msg.className = "center ok";
    msg.textContent = "Thank you! Your idea reached the team.";
    const { sent = [] } = await chrome.storage.local.get("sent");
    await chrome.storage.local.set({ sent: [idea.slice(0, 60), ...sent].slice(0, 5) });
    $("suggest-idea").value = "";
    loadSent();
  } catch (e) {
    msg.className = "center bad";
    msg.textContent = e.message;
  } finally {
    $("suggest-btn").disabled = false;
  }
});
loadSent();
